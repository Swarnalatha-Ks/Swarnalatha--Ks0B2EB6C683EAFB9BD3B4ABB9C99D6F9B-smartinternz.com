# Function to calculate the factorial of a number
def factorial(num):
    if num == 0:
        return 1
    else:
        return num * factorial(num - 1)

# Input two numbers
num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))

# Calculate and display the factorial of the first number
factorial1 = factorial(num1)
print(f"Factorial of {num1} is {factorial1}")

# Calculate and display the factorial of the second number
factorial2 = factorial(num2)
print(f"Factorial of {num2} is {factorial2}")
